package com.example.nextnest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class Login {

    @FXML
    private TextField t1; // Mobile Number
    @FXML
    private PasswordField p1; // Password

    // Shift to Signup scene
    @FXML
    public void shiftScene(ActionEvent e) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("signup.fxml"));
        Scene loginScene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(loginScene);
        stage.show();
    }

    // Login button action
    @FXML
    public void login(ActionEvent e) {
        String mobileNumber = t1.getText();
        String password = p1.getText();

        // Validate input fields
        if (mobileNumber.isEmpty() || password.isEmpty()) {
            showAlert("Error", "Please fill in both mobile number and password.", Alert.AlertType.ERROR);
            return;
        }

        // Create a User object for validation
        User user = new User();
        user.setNumber(mobileNumber);
        user.setPassword(password);

        // Validate login credentials
        LogSignUtils.loginUser(e, user);
    }

    // Utility method for displaying alerts
    // Utility method for displaying alerts with custom design
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null); // Remove default header
        alert.setContentText(message);

        // Add a custom image icon
        ImageView icon = new ImageView(new Image("img.png")); // Adjust the file path
        icon.setFitWidth(40); // Set custom width
        icon.setFitHeight(40); // Set custom height
        alert.setGraphic(icon); // Add icon to alert

        Stage alertStage = (Stage) alert.getDialogPane().getScene().getWindow();
        alertStage.getIcons().add(new Image("img.png"));

        // Customize dialog pane style (optional)
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #f0f8ff; " + // Background color (light blue)
                "-fx-border-color: #4682b4; " + // Border color (steel blue)
                "-fx-border-width: 2px; " // Border width
        );

        // Customize button style (optional)
        dialogPane.lookupButton(ButtonType.OK).setStyle("-fx-background-color: #4682b4; " + // Button background color
                "-fx-text-fill: white; " + // Button text color
                "-fx-font-size: 14px;" // Button text size
        );

        // Show the alert
        alert.showAndWait();
    }
}
